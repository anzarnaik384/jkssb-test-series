package com.jkssb.testseries;

import android.app.*;
import android.os.*;
import android.graphics.Color;
import android.content.*;
import android.view.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    LinearLayout content;
    TextView title;
    int blue=Color.rgb(13,71,161);
    Map<String,String[]> questions=new LinkedHashMap<>();
    Map<String,String[]> answers=new LinkedHashMap<>();
    int qIndex=0, score=0;
    long endTime;

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        title=findViewById(R.id.title); content=findViewById(R.id.content);
        loadQuestions(); home();
    }

    void loadQuestions(){
        add("General Knowledge",
            new String[]{"The capital of Jammu and Kashmir is?","Which river is associated with Jammu?","Who wrote 'Rajatarangini'?"},
            new String[]{"Srinagar","Tawi","Kalhana"},
            new String[]{"Jammu","Tawi","Kalhana"});
        add("Indian Polity",
            new String[]{"Fundamental Rights are contained in which Part of the Constitution?","Article 14 deals with?","Who is the constitutional head of India?"},
            new String[]{"Part III","Equality before law","President"},
            new String[]{"Part III","Equality before law","President"});
        add("Computer",
            new String[]{"BIOS is stored in?","Which is an input device?","CPU stands for?"},
            new String[]{"ROM/flash memory","Keyboard","Central Processing Unit"},
            new String[]{"ROM/flash memory","Keyboard","Central Processing Unit"});
        add("English",
            new String[]{"Choose the correct article: He is ___ honest man.","Past tense of 'go' is?","A word used in place of a noun is called?"},
            new String[]{"an","went","pronoun"},
            new String[]{"an","went","pronoun"});
        add("Mathematics",
            new String[]{"What is 15% of 200?","If 3:5 = x:20, x = ?","12 × 8 = ?"},
            new String[]{"30","12","96"},
            new String[]{"30","12","96"});
        add("Reasoning",
            new String[]{"Find the next number: 2, 4, 8, 16, ?","Odd one out: Apple, Mango, Potato, Banana","If A=1, B=2, then C=?"},
            new String[]{"32","Potato","3"},
            new String[]{"32","Potato","3"});
        add("Geography",
            new String[]{"Which is the largest ocean?","The Himalayas are mainly in which part of India?","Which line divides Earth into Northern and Southern Hemispheres?"},
            new String[]{"Pacific Ocean","North","Equator"},
            new String[]{"Pacific Ocean","North","Equator"});
        add("History",
            new String[]{"Who founded the Maurya Empire?","The Quit India Movement began in?","Who was known as the Iron Man of India?"},
            new String[]{"Chandragupta Maurya","1942","Sardar Patel"},
            new String[]{"Chandragupta Maurya","1942","Sardar Patel"});
        add("Science",
            new String[]{"Plants prepare food by?","Water boils at sea level at?","Which organ pumps blood?"},
            new String[]{"Photosynthesis","100°C","Heart"},
            new String[]{"Photosynthesis","100°C","Heart"});
        add("Current Affairs",
            new String[]{"Current affairs questions in this app should be updated how often?","For an exam, current-affairs facts should be checked against?","A good test series should track?"},
            new String[]{"Regularly","Reliable recent sources","Score and accuracy"},
            new String[]{"Regularly","Reliable recent sources","Score and accuracy"});
    }

    void add(String cat,String[] qs,String[] correct,String[] ans){
        questions.put(cat,qs); answers.put(cat,correct);
    }

    void base(){
        content.removeAllViews();
        title.setText("JKSSB Test Series");
    }

    Button btn(String text){
        Button b=new Button(this); b.setText(text); b.setTextSize(16);
        b.setAllCaps(false); b.setTextColor(Color.WHITE); b.setBackgroundColor(blue);
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,60); lp.setMargins(0,8,0,8);
        b.setLayoutParams(lp); return b;
    }

    void home(){
        base();
        TextView h=new TextView(this); h.setText("Choose a test"); h.setTextSize(21); h.setTextColor(blue);
        content.addView(h);
        for(final String cat: questions.keySet()){
            Button b=btn(cat+"  •  Sectional Test");
            b.setOnClickListener(v->startTest(cat));
            content.addView(b);
        }
        Button full=btn("FULL LENGTH MOCK TEST");
        full.setOnClickListener(v->startFull()); content.addView(full);
    }

    void startFull(){
        final ArrayList<String> cats=new ArrayList<>(questions.keySet());
        final ArrayList<String> qs=new ArrayList<>(), cs=new ArrayList<>();
        for(String c:cats){qs.addAll(Arrays.asList(questions.get(c)));cs.addAll(Arrays.asList(answers.get(c)));}
        runTest("Full Length Mock",qs,cs);
    }

    void startTest(String cat){
        runTest(cat,new ArrayList<>(Arrays.asList(questions.get(cat))),new ArrayList<>(Arrays.asList(answers.get(cat))));
    }

    void runTest(String name,ArrayList<String> qs,ArrayList<String> cs){
        base(); qIndex=0; score=0; endTime=System.currentTimeMillis()+10*60*1000L;
        showQuestion(name,qs,cs);
    }

    void showQuestion(String name,ArrayList<String> qs,ArrayList<String> cs){
        if(qIndex>=qs.size()){result(name,qs,cs);return;}
        content.removeAllViews();
        TextView timer=new TextView(this); timer.setTextSize(16); timer.setTextColor(blue);
        content.addView(timer);
        TextView q=new TextView(this); q.setText((qIndex+1)+". "+qs.get(qIndex)); q.setTextSize(19); q.setPadding(0,20,0,20);
        content.addView(q);
        String[] opts={"A","B","C","D"};
        String correct=cs.get(qIndex);
        for(String o:opts){
            Button b=btn(o+"   "+correct);
            b.setOnClickListener(v->{score++; qIndex++; showQuestion(name,qs,cs);});
            content.addView(b);
        }
        new CountDownTimer(10*60*1000L,1000){
            public void onTick(long m){timer.setText("Time left: "+(m/60000)+":"+String.format("%02d",(m/1000)%60));}
            public void onFinish(){if(qIndex<qs.size()){qIndex=qs.size();result(name,qs,cs);}}
        }.start();
    }

    void result(String name,ArrayList<String> qs,ArrayList<String> cs){
        content.removeAllViews();
        TextView r=new TextView(this); r.setText("Test Completed"); r.setTextSize(26); r.setTextColor(blue); r.setPadding(0,20,0,20);
        content.addView(r);
        TextView s=new TextView(this); s.setText("Score: "+score+" / "+qs.size()+"\nAccuracy: "+(qs.size()==0?0:(score*100/qs.size()))+"%");
        s.setTextSize(21); s.setPadding(0,10,0,20); content.addView(s);
        Button home=btn("Back to Home"); home.setOnClickListener(v->home()); content.addView(home);
    }
}
